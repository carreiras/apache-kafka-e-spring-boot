package carreiras.com.github.shopvalidator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopValidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopValidatorApplication.class, args);
	}

}
